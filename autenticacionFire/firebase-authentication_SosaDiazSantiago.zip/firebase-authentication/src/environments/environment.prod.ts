export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyCcyhHt_JI6_6H43ZU6UkaI4T7VFdxhjEc",
    authDomain: "schoolapp-8eda2.firebaseapp.com",
    projectId: "schoolapp-8eda2",
    storageBucket: "schoolapp-8eda2.appspot.com",
    messagingSenderId: "525641232020",
    appId: "1:525641232020:web:27070336e12df082004e81",
    measurementId: "G-QDQLC7WQT3"
  }
};
